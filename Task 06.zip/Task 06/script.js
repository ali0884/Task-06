document.addEventListener("DOMContentLoaded", function () {
    const bookList = document.getElementById("book-list");
    const addBookForm = document.getElementById("add-book-form");
    const searchInput = document.getElementById("search");
    const searchResults = document.getElementById("search-results");

    
    const books = [
        { title: "Physics", author: "Richard Feynman", isbn: "374" },
        { title: "Bio", author: "Bernd Heinrich", isbn: "78" },
        { title: "english", author: "mark", isbn: "1122" }
    ];

    function displayBookList() {
        bookList.innerHTML = "";
        books.forEach(book => {
            const listItem = document.createElement("li");
            listItem.innerHTML = `<strong>${book.title}</strong> by ${book.author}, ISBN: ${book.isbn}`;
            bookList.appendChild(listItem);
        });
    }

    addBookForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const title = document.getElementById("title").value;
        const author = document.getElementById("author").value;
        const isbn = document.getElementById("isbn").value;
        
        books.push({ title, author, isbn });
        displayBookList();
        addBookForm.reset();
    });

    
    searchInput.addEventListener("input", function () {
        const query = searchInput.value.toLowerCase();
        const results = books.filter(book => book.title.toLowerCase().includes(query) || book.author.toLowerCase().includes(query) || book.isbn.includes(query));
        searchResults.innerHTML = "";
        results.forEach(result => {
            const listItem = document.createElement("li");
            listItem.textContent = `${result.title} by ${result.author}, ISBN: ${result.isbn}`;
            searchResults.appendChild(listItem);
        });
    });

    displayBookList();
});
